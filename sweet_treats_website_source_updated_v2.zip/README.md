# Sweet Treats — Website Preview

## Isi folder
- `index.html` — website preview (HTML, CSS, JavaScript dalam satu file)
- `assets/logo-sweet-treats.png` — logo Sweet Treats

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser (Chrome/Edge/Firefox).
3. Koneksi internet diperlukan agar Google Fonts dan foto produk dari Unsplash dapat dimuat.

## Catatan
- Ini adalah prototype front-end; checkout masih simulasi.
- Harga dan deskripsi produk merupakan contoh dan dapat diedit di array `products` pada bagian `<script>` di `index.html`.
- Foto produk menggunakan URL Unsplash dan dapat diganti dengan foto produk milik toko.
- Daftar saat ini memuat 9 menu setelah menghapus Salt Bread, Dubai Chewy Cookie, Choux Cream, Donat, Slice Cake, dan Butter Ttoek.
- Tidak ada backend, database, WhatsApp order integration, atau payment gateway yang terhubung.
